import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://raw.githubusercontent.com/latinboykodi/wizard/master/builds.json'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://raw.githubusercontent.com/latinboykodi/wizard/master/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
